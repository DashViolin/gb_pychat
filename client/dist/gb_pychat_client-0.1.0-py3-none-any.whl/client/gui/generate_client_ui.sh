poetry run python -m PyQt6.uic.pyuic -o main_window.py -x client_gui.ui
