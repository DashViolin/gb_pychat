from client.application import Application


application = Application()
application.run()
