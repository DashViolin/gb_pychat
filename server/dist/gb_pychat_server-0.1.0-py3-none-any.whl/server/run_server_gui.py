from server.application import Application


def run():
    application = Application()
    application.run()


if __name__ == "__main__":
    run()
