from server.application import Application


application = Application()
application.run()
